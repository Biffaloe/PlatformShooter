﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour 
{
	public GameObject bulletPrefab;
	public float timeBetweenBullets = 0.15f;

	float timer;
	float effectsDisplayTime = 0.2f;
	Light gunLight;

	void Awake ()
	{
		gunLight = GetComponent<Light> ();
	}

	void Update()
	{
		timer += Time.deltaTime;

		if(Input.GetButton("Fire1") && timer >= timeBetweenBullets)
		{
			shootBullet();
		}

		if (timer >= timeBetweenBullets * effectsDisplayTime){
			gunLight.enabled = false;
		}
	}

	public void shootBullet()
	{
		timer = 0f;

		gunLight.enabled = true;

		GameObject b = Instantiate(bulletPrefab) as GameObject;
		b.transform.position = this.transform.position;
	}
}
