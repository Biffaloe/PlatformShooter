﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour {

public float speed = 2.0f;
public float range = 20.0f;
private Rigidbody rb;
private Vector3 length;

	void Start () 
	{
		rb = this.GetComponent<Rigidbody>();
		length = new Vector3(0,0,range);
		rb.velocity = new Vector3(0,0,speed);
	}
	
	void Update () 
	{
		if(transform.position.z > range)
		{
			Destroy(this.gameObject);
		}
	}
}
